import { searchMeanings } from "./js/services/searchService.js";
import {
  deleteGlossaryItem,
  readGlossary,
  saveGlossaryItem,
} from "./js/storage/glossaryStorage.js";
import {
  clearSearchHistory,
  loadSearchHistory,
  recordSearchHistory,
} from "./js/storage/historyStorage.js";
import { initializeSearchUI } from "./js/ui/searchUI.js";
import { initializeGlossaryUI } from "./js/ui/glossaryUI.js";
import { initializeModalUI } from "./js/ui/modalUI.js";
import { getSelectedTextFromActiveTab } from "./js/features/selectText.js";

let currentWord = null;
let activeSearchId = 0;

async function loadGlossary() {
  try {
    const glossary = await readGlossary();
    glossaryUI.render(glossary);
  } catch (error) {
    glossaryUI.showLoadError(error);
  }
}

async function confirmGlossaryDeletion(item) {
  await deleteGlossaryItem(item);
  await loadGlossary();
}

const modalUI = initializeModalUI({ onConfirmDelete: confirmGlossaryDeletion });

async function clearHistory() {
  try {
    const history = await clearSearchHistory();
    searchUI.renderHistory(history);
    searchUI.clearHistoryStatus();
  } catch (error) {
    searchUI.showHistoryError(error);
  }
}

const searchUI = initializeSearchUI({
  onSearch: searchWord,
  onHistorySearch(term) {
    searchUI.setSearchTerm(term);
    document.getElementById("searchHistoryPanel").open = false;
    searchWord();
  },
  onClearHistory: clearHistory,
});

const glossaryUI = initializeGlossaryUI({
  onOpen: loadGlossary,
  onSearch: loadGlossary,
  onDelete: (item, trigger) => modalUI.openDeleteModal(item, trigger),
});

async function searchWord() {
  const searchId = ++activeSearchId;
  const word = searchUI.getSearchTerm();
  if (!word) {
    currentWord = null;
    searchUI.showRequiredTerm();
    searchUI.setBusy(false);
    return;
  }

  recordSearchHistory(word).then((history) => {
    searchUI.renderHistory(history);
    searchUI.clearHistoryStatus();
  }).catch((error) => searchUI.showHistoryError(error));

  searchUI.setBusy(true);
  searchUI.showSearching();
  currentWord = null;

  try {
    const result = await searchMeanings(word);
    if (searchId !== activeSearchId) return;
    currentWord = result.currentWord;
    searchUI.renderResult(currentWord, result);
  } catch (error) {
    if (searchId !== activeSearchId) return;
    currentWord = null;
    searchUI.showSearchError(error);
  } finally {
    if (searchId === activeSearchId) searchUI.setBusy(false);
  }
}

document.getElementById("saveBtn").addEventListener("click", async () => {
  if (!currentWord) return;
  const saveBtn = document.getElementById("saveBtn");
  saveBtn.disabled = true;
  try {
    const result = await saveGlossaryItem(currentWord);
    if (result.duplicate) {
      modalUI.showDuplicateSave();
      return;
    }
    modalUI.showSaveSuccess();
  } catch (error) {
    console.error("Save Error:", error);
    alert("Gagal menyimpan istilah.");
  } finally {
    saveBtn.disabled = false;
  }
});

async function loadSelectedText() {
  try {
    const selectedText = await getSelectedTextFromActiveTab();
    if (!selectedText) return;
    searchUI.setSearchTerm(selectedText);
    await searchWord();
  } catch (error) {
    console.error("Select & Click Error:", error);
    searchUI.showUnsupportedPage();
  }
}

loadSearchHistory()
  .then((history) => searchUI.renderHistory(history))
  .catch((error) => searchUI.showHistoryError(error));
loadSelectedText();
