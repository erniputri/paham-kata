import {
  InvalidGlossaryDataError,
  isValidGlossaryItem,
  getProgrammingMeanings,
} from "../storage/glossaryStorage.js";

const elements = {
  searchSection: document.querySelector(".search-section"),
  resultSection: document.getElementById("resultSection"),
  popupContainer: document.querySelector(".container"),
  glossaryBtn: document.getElementById("glossaryBtn"),
  glossarySection: document.getElementById("glossarySection"),
  glossaryList: document.getElementById("glossaryList"),
  glossaryEmpty: document.getElementById("glossaryEmpty"),
  glossaryNoResults: document.getElementById("glossaryNoResults"),
  glossaryCount: document.getElementById("glossaryCount"),
  glossaryDataWarning: document.getElementById("glossaryDataWarning"),
  glossarySearch: document.getElementById("glossarySearch"),
  backBtn: document.getElementById("backBtn"),
};

function renderGlossary(storedGlossary, onDelete) {
  const glossary = storedGlossary.filter(isValidGlossaryItem);
  const invalidCount = storedGlossary.length - glossary.length;

  elements.glossaryCount.textContent = glossary.length;
  elements.glossaryList.replaceChildren();
  elements.glossaryDataWarning.hidden = invalidCount === 0;
  if (invalidCount > 0) {
    elements.glossaryDataWarning.textContent =
      `${invalidCount} entri tidak dapat dibaca dan dilewati. Data tersimpan tidak diubah.`;
  }

  if (storedGlossary.length === 0) {
    elements.glossaryEmpty.hidden = false;
    elements.glossaryNoResults.hidden = true;
    return;
  }
  elements.glossaryEmpty.hidden = true;
  if (glossary.length === 0) {
    elements.glossaryNoResults.hidden = true;
    return;
  }

  const keyword = elements.glossarySearch.value.trim().toLowerCase();
  const filteredGlossary = glossary.filter((item) => {
    const general = item.generalMeaning;
    const programming = getProgrammingMeanings(item.programmingMeaning);
    return (
      item.word.toLowerCase().includes(keyword) ||
      item.translation.toLowerCase().includes(keyword) ||
      item.definition.toLowerCase().includes(keyword) ||
      [general?.definition, general?.translation, general?.partOfSpeech,
        ...programming.flatMap((meaning) => [meaning.term, meaning.category,
          meaning.definition, meaning.simpleExplanation])]
        .some((value) => typeof value === "string" && value.toLowerCase().includes(keyword))
    );
  });

  if (filteredGlossary.length === 0) {
    elements.glossaryNoResults.hidden = false;
    return;
  }
  elements.glossaryNoResults.hidden = true;

  filteredGlossary.forEach((item, index) => {
    const glossaryItem = document.createElement("div");
    glossaryItem.className = "glossary-item";
    const word = document.createElement("h4");
    word.textContent = `${index + 1}. ${item.word}`;

    const programming = getProgrammingMeanings(item.programmingMeaning);
    const general = item.generalMeaning;
    const hasStructuredMeaning = Boolean(programming.length || general);

    programming.forEach((meaning) => {
      const programmingBlock = document.createElement("div");
      programmingBlock.className = "glossary-meaning glossary-programming";
      const heading = document.createElement("strong");
      heading.textContent = `Pemrograman · ${meaning.category || "Programming Concept"}`;
      const definition = document.createElement("p");
      definition.className = "definition";
      definition.textContent = meaning.definition || "";
      programmingBlock.append(heading, definition);
      if (meaning.simpleExplanation) {
        const explanation = document.createElement("p");
        explanation.className = "translation";
        explanation.textContent = meaning.simpleExplanation;
        programmingBlock.appendChild(explanation);
      }
      glossaryItem.appendChild(programmingBlock);
    });

    if (general) {
      const generalBlock = document.createElement("div");
      generalBlock.className = "glossary-meaning glossary-general";
      const heading = document.createElement("strong");
      heading.textContent = "Makna umum";
      const definition = document.createElement("p");
      definition.className = "definition";
      definition.textContent = general.definition || "";
      generalBlock.append(heading, definition);
      const translated = document.createElement("p");
      translated.className = "translation";
      translated.textContent = general.translation
        ? `Terjemahan: ${general.translation}`
        : "Terjemahan belum tersedia.";
      generalBlock.appendChild(translated);
      glossaryItem.appendChild(generalBlock);
    }

    // Entri sebelum format konteks tetap ditampilkan dengan data lamanya.
    if (!hasStructuredMeaning) {
      const translation = document.createElement("p");
      translation.className = "translation";
      translation.textContent = item.translation
        ? `Arti: ${item.translation}`
        : "Terjemahan belum tersedia.";
      const definition = document.createElement("p");
      definition.className = "definition";
      definition.textContent = `Definisi (EN): ${item.definition}`;
      glossaryItem.append(translation, definition);
    }

    const savedDate = document.createElement("small");
    savedDate.className = "saved-date";
    const date = new Date(item.savedAt);
    savedDate.textContent = "Disimpan: " +
      (Number.isNaN(date.getTime()) ? "-" : date.toLocaleDateString("id-ID"));

    const deleteButton = document.createElement("button");
    deleteButton.className = "glossary-delete";
    deleteButton.textContent = "Hapus";
    deleteButton.addEventListener("click", () => onDelete(item, deleteButton));

    glossaryItem.append(word, savedDate, deleteButton);
    elements.glossaryList.appendChild(glossaryItem);
  });
}

export function initializeGlossaryUI({ onOpen, onSearch, onDelete }) {
  elements.glossaryBtn.addEventListener("click", async () => {
    elements.searchSection.hidden = true;
    elements.resultSection.hidden = true;
    elements.glossarySection.hidden = false;
    elements.popupContainer.classList.add("glossary-open");
    elements.glossarySearch.value = "";
    await onOpen();
  });

  elements.backBtn.addEventListener("click", () => {
    elements.glossarySection.hidden = true;
    elements.popupContainer.classList.remove("glossary-open");
    elements.searchSection.hidden = false;
    elements.resultSection.hidden = false;
  });

  elements.glossarySearch.addEventListener("input", onSearch);

  return {
    render: (items) => renderGlossary(items, onDelete),
    showLoadError(error) {
      console.error("Load Glossary Error:", error);
      if (error instanceof InvalidGlossaryDataError) {
        elements.glossaryList.replaceChildren();
        elements.glossaryCount.textContent = "—";
        elements.glossaryEmpty.hidden = true;
        elements.glossaryNoResults.hidden = true;
        elements.glossaryDataWarning.hidden = false;
        elements.glossaryDataWarning.textContent =
          "Format data Glosarium tidak dapat dibaca. Data tersimpan tidak diubah.";
        return;
      }
      alert("Gagal memuat Glosarium Saya.");
    },
  };
}
